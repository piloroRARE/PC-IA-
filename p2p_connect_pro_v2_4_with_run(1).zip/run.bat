@echo off
echo Starting P2P Connect Pro...
python app.py
pause
