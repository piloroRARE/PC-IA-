import os
import sys
import subprocess

def main():
    print("=== P2P Connect Pro v2.4 ===")
    print("Démarrage du serveur et lancement de l'application...")
    
    # Run server.py or open HTML
    if os.path.exists("server.py"):
        subprocess.run([sys.executable, "server.py"])
    else:
        print("Fichier server.py introuvable.")

if __name__ == "__main__":
    main()
