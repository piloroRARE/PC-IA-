import http.server
import socketserver
import webbrowser

PORT = 8000
Handler = http.server.SimpleHTTPRequestHandler

print(f"Serveur démarré sur http://localhost:{PORT}")
webbrowser.open(f"http://localhost:{PORT}/p2p_connect_pro_v2_4.html")

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur.")
