# P2P Connect Pro v2.4

## Instructions d'exécution

### Méthode simple (Windows) :
Double-cliquez sur `run.bat` pour lancer automatiquement l'application.

### Méthode manuelle :
Exécutez dans votre terminal :
```bash
python app.py
```
