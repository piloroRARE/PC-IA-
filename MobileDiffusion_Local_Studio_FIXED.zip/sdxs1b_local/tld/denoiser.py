"""Compatibility shim for MobileDiffusion's custom Denoiser class.

The Hugging Face checkpoint declares its UNet component as
`tld.denoiser.Denoiser`, while the released checkpoint configuration uses
the standard Diffusers UNet2DConditionModel configuration/state-dict layout.
This class intentionally inherits the matching Diffusers implementation so
Diffusers can reconstruct the checkpoint without requiring the original
private module.
"""
from diffusers import UNet2DConditionModel


class Denoiser(UNet2DConditionModel):
    """MobileDiffusion-compatible UNet wrapper."""

    pass
