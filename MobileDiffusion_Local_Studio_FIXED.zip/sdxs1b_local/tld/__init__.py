"""Compatibility package for ikozlov/MobileDiffusion."""
from .denoiser import Denoiser

__all__ = ["Denoiser"]
