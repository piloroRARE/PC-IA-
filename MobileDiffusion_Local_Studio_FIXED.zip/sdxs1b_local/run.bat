@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
  set PY=py
) else (
  set PY=python
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creation de l'environnement virtuel...
  %PY% -3.11 -m venv .venv
  if errorlevel 1 %PY% -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

set IMAGE_MODEL_ID=ikozlov/MobileDiffusion
set IMAGE_WIDTH=256
set IMAGE_HEIGHT=256
set IMAGE_ECO_THREADS=2
set IMAGE_NORMAL_THREADS=4
set IMAGE_ECO_STEPS=4
set IMAGE_NORMAL_STEPS=8

python -m app.main
pause
