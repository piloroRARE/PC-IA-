# MobileDiffusion Local Studio

Application locale Python/Web pour générer des images PNG avec **MobileDiffusion (~0,3B paramètres annoncés)** via Diffusers.

La page Hugging Face du modèle indique un pipeline `StableDiffusionPipeline`, des poids `F32` et environ `0,3B` paramètres. Le pipeline contient `unet`, `text_encoder`, `tokenizer` et `vae`. Voir : https://huggingface.co/ikozlov/MobileDiffusion

## Architecture

```text
Navigateur
   │
   ▼
Flask (127.0.0.1:5000)
   │
   ▼
Worker Python / verrou de génération
   │
   ▼
Diffusers + MobileDiffusion
   │
   ▼
PNG local
```

## Installation Windows

1. Installer Python 3.11 ou 3.12.
2. Double-cliquer sur `run.bat`.
3. Le script crée `.venv` et installe les dépendances.
4. Ouvrir `http://127.0.0.1:5000`.
5. Au premier lancement, Hugging Face télécharge le modèle.

## Mode ECO

- 2 threads CPU par défaut.
- 4 étapes d'inférence par défaut.
- résolution recommandée 256x256.
- batch de 1.

Le mode normal passe à 4 threads et 8 étapes. Ces valeurs sont configurables par variables d'environnement.

## Variables

```text
IMAGE_MODEL_ID=ikozlov/MobileDiffusion
IMAGE_MODEL_REVISION=
IMAGE_WIDTH=256
IMAGE_HEIGHT=256
IMAGE_ECO_THREADS=2
IMAGE_NORMAL_THREADS=4
IMAGE_ECO_STEPS=4
IMAGE_NORMAL_STEPS=8
IMAGE_HOST=127.0.0.1
IMAGE_PORT=5000
```

## Important sur la contrainte matérielle

Le chiffre `0,3B` est la valeur annoncée par la fiche du dépôt. La taille disque actuelle du dépôt est d'environ 2,17 GB, et le dépôt contient séparément le VAE, le tokenizer, le text encoder et l'UNet. Cela ne signifie donc pas que l'exécution CPU utilisera seulement 0,3 GB de RAM.

## Moteurs interchangeables

Le backend isole `IMAGE_MODEL_ID`. On pourra donc ajouter ultérieurement SANA-0.6B ou un autre moteur sans réécrire l'interface Web.


## Correction MobileDiffusion

Le checkpoint `ikozlov/MobileDiffusion` déclare son composant UNet sous `tld.denoiser.Denoiser`. Le projet inclut maintenant un shim local `tld/` compatible avec la configuration Diffusers du checkpoint, afin d'éviter l'erreur « tld.denoiser.py does not exist ». Diffusers est épinglé sur la branche 0.27.x correspondant au checkpoint.
