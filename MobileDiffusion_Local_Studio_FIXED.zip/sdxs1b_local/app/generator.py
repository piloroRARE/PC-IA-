from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Any

import torch
from diffusers import DiffusionPipeline

from .config import SETTINGS


class ImageGenerator:
    """Local CPU image generator with a small, single-job queue."""

    def __init__(self) -> None:
        self._pipe: DiffusionPipeline | None = None
        self._model_lock = threading.Lock()
        self._job_lock = threading.Lock()
        self._status: dict[str, Any] = {
            "state": "idle",
            "message": "Prêt.",
            "started": None,
            "model": SETTINGS.model_id,
            "queue": False,
        }

        # PyTorch can otherwise use every logical CPU thread.
        self._set_threads(True)

    def _set_threads(self, eco: bool) -> None:
        threads = SETTINGS.eco_threads if eco else SETTINGS.normal_threads
        threads = max(1, min(threads, os.cpu_count() or 1))
        torch.set_num_threads(threads)
        try:
            torch.set_num_interop_threads(max(1, min(2, threads)))
        except RuntimeError:
            pass

    def _load(self, eco: bool) -> DiffusionPipeline:
        if self._pipe is not None:
            return self._pipe

        with self._model_lock:
            if self._pipe is not None:
                return self._pipe

            self._set_threads(eco)
            self._set_status("loading", "Chargement de MobileDiffusion…")

            kwargs: dict[str, Any] = {
                "torch_dtype": torch.float32,
                "safety_checker": None,
            }
            if SETTINGS.model_revision:
                kwargs["revision"] = SETTINGS.model_revision

            pipe = DiffusionPipeline.from_pretrained(SETTINGS.model_id, **kwargs)
            pipe = pipe.to("cpu")
            pipe.set_progress_bar_config(disable=True)

            # Helps CPU inference a little on supported Diffusers pipelines.
            try:
                pipe.enable_attention_slicing()
            except Exception:
                pass

            self._pipe = pipe
            return pipe

    def _set_status(self, state: str, message: str, *, queue: bool | None = None) -> None:
        self._status.update({
            "state": state,
            "message": message,
            "started": time.time() if state in {"loading", "generating"} else None,
        })
        if queue is not None:
            self._status["queue"] = queue

    def status(self) -> dict[str, Any]:
        return dict(self._status)

    def generate(self, prompt: str, negative_prompt: str, width: int, height: int, seed: int, eco: bool) -> tuple[Path, dict[str, Any]]:
        if not prompt.strip():
            raise ValueError("Le prompt est vide.")

        if width % 8 or height % 8:
            raise ValueError("La largeur et la hauteur doivent être des multiples de 8.")
        if width < 128 or height < 128 or width > 768 or height > 768:
            raise ValueError("Résolution autorisée : 128 à 768 px, par pas de 8.")

        if not self._job_lock.acquire(blocking=False):
            self._status["queue"] = True
            raise RuntimeError("Une génération est déjà en cours. Attends qu'elle se termine.")

        started = time.time()
        try:
            self._set_threads(eco)
            self._set_status("generating", "Génération en cours…", queue=False)
            pipe = self._load(eco)

            steps = SETTINGS.eco_steps if eco else SETTINGS.normal_steps
            generator = torch.Generator(device="cpu").manual_seed(int(seed))

            call_kwargs: dict[str, Any] = {
                "prompt": prompt.strip(),
                "width": width,
                "height": height,
                "num_inference_steps": max(1, steps),
                "generator": generator,
            }
            if negative_prompt.strip():
                call_kwargs["negative_prompt"] = negative_prompt.strip()

            result = pipe(**call_kwargs)
            image = result.images[0]

            SETTINGS.output_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            filename = f"mobile_{stamp}_{seed}.png"
            output = SETTINGS.output_dir / filename
            image.save(output, format="PNG", optimize=True)

            meta = {
                "prompt": prompt.strip(),
                "negative_prompt": negative_prompt.strip(),
                "width": width,
                "height": height,
                "seed": int(seed),
                "eco": bool(eco),
                "steps": steps,
                "model": SETTINGS.model_id,
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "duration_seconds": round(time.time() - started, 2),
            }
            self._set_status("ready", "Image générée.", queue=False)
            return output, meta
        except Exception as exc:
            self._set_status("error", str(exc), queue=False)
            raise
        finally:
            self._job_lock.release()
