from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    model_id: str = os.getenv("IMAGE_MODEL_ID", "ikozlov/MobileDiffusion")
    model_revision: str = os.getenv("IMAGE_MODEL_REVISION", "")
    host: str = os.getenv("IMAGE_HOST", "127.0.0.1")
    port: int = _env_int("IMAGE_PORT", 5000)
    output_dir: Path = BASE / "outputs"
    default_width: int = _env_int("IMAGE_WIDTH", 256)
    default_height: int = _env_int("IMAGE_HEIGHT", 256)
    eco_threads: int = _env_int("IMAGE_ECO_THREADS", 2)
    normal_threads: int = _env_int("IMAGE_NORMAL_THREADS", 4)
    eco_steps: int = _env_int("IMAGE_ECO_STEPS", 4)
    normal_steps: int = _env_int("IMAGE_NORMAL_STEPS", 8)


SETTINGS = Settings()
