from __future__ import annotations

import random
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_from_directory

from .config import SETTINGS
from .generator import ImageGenerator

BASE = Path(__file__).resolve().parent.parent
app = Flask(__name__, template_folder=str(BASE / "templates"), static_folder=str(BASE / "static"))
generator = ImageGenerator()


@app.get("/")
def index():
    return render_template("index.html", defaults={
        "width": SETTINGS.default_width,
        "height": SETTINGS.default_height,
    })


@app.get("/api/status")
def status():
    return jsonify(generator.status())


@app.post("/api/generate")
def generate():
    data = request.get_json(silent=True) or {}
    try:
        prompt = str(data.get("prompt", ""))
        negative_prompt = str(data.get("negative_prompt", ""))
        width = int(data.get("width", SETTINGS.default_width))
        height = int(data.get("height", SETTINGS.default_height))
        seed_value = data.get("seed")
        seed = random.randint(0, 2_147_483_647) if seed_value in (None, "", "random") else int(seed_value)
        eco = bool(data.get("eco", True))

        output, meta = generator.generate(prompt, negative_prompt, width, height, seed, eco)
        return jsonify({
            "ok": True,
            "image": f"/outputs/{output.name}",
            "filename": output.name,
            "meta": meta,
        })
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "busy": True}), 409
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.get("/outputs/<path:filename>")
def outputs(filename: str):
    return send_from_directory(SETTINGS.output_dir, filename, as_attachment=False)


if __name__ == "__main__":
    SETTINGS.output_dir.mkdir(parents=True, exist_ok=True)
    app.run(host=SETTINGS.host, port=SETTINGS.port, debug=False, threaded=True)
